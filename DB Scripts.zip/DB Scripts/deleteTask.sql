USE [TaskTrackerDb]
GO

/****** Object:  StoredProcedure [dbo].[DeleteTask]    Script Date: 08-10-2025 11:27:59 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[DeleteTask]
    @taskId INT
AS
BEGIN 
	insert into deleted_tasks
		(
			[task_id]
			,[title]
			,[description]
			,[assigned_user]
			,[status]
			,[due_date]
			,[created_at]
			,[modified_at]
			,[completed_at]
		)
	select 
			[task_id]
			,[title]
			,[description]
			,[assigned_user]
			,[status]
			,[due_date]
			,[created_at]
			,[modified_at]
			,[completed_at]
	FROM tasks 
	WHERE task_id = @taskId
 
    DELETE FROM tasks 
	WHERE task_id = @taskId;
	 
END
GO

