USE [TaskTrackerDb]
GO

/****** Object:  StoredProcedure [dbo].[UpdateTaskStatus]    Script Date: 08-10-2025 11:28:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[UpdateTaskStatus]
    @taskId INT,
    @status INT
AS
BEGIN
     
	UPDATE tasks
    SET 
		status = @status, 
		completed_at = case when @status = 2 then DateAdd(minute, 330, GETUTCDATE()) else completed_at end,
		modified_at = DateAdd(minute, 330, GETUTCDATE())
    WHERE
		task_id = @taskId;
 
END
GO

