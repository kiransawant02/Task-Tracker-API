USE [TaskTrackerDb]
GO

/****** Object:  StoredProcedure [dbo].[UpdateTask]    Script Date: 08-10-2025 11:28:10 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[UpdateTask]
    @taskId INT,
    @title NVARCHAR(200),
    @description NVARCHAR(MAX),
    @assigned_user NVARCHAR(200),
    @status tinyint,
    @due_date DATETIME  
AS
BEGIN 
 
    UPDATE tasks
    SET
        title = @title,
        description = @description,
        assigned_user = @assigned_user,
        status = @status,
        due_date = @due_date,
		modified_at = DATEADD(minute, 330,GETUTCDATE())
    WHERE task_id = @taskId;
	 
END
GO

