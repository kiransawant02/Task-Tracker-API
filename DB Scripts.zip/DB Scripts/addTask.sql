USE [TaskTrackerDb]
GO

/****** Object:  StoredProcedure [dbo].[AddTask]    Script Date: 08-10-2025 11:27:48 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[AddTask]
    @title NVARCHAR(200),
    @description NVARCHAR(MAX),
    @assigned_user NVARCHAR(200),
    @status tinyint,
    @due_date DATETIME 
AS
BEGIN 

    INSERT INTO tasks 
		(title, description, assigned_user, status, due_date)
    VALUES 
		(@title, @description, @assigned_user, @status, @due_date);
     
END;
GO

